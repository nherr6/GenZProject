class Letter{
  constructor(){
    
  }
}
