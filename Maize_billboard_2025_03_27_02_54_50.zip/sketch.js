// Click and drag the mouse to view the scene from different angles.

let myGeometry;
let font;
let n = 0;

function preload(){
  font = loadFont("Roboto-Regular.ttf");
}

function setup() {
  createCanvas(400, 400, WEBGL);

  // Create a p5.Geometry object.
  beginGeometry();
  //torus(30, 15, 10, 8);
  sphere(100);
  myGeometry = endGeometry();

  describe('A white torus rotates slowly against a dark gray background. Red spheres mark its vertices.');
}

function draw() {
  background(0);

  // Enable orbiting with the mouse.
  orbitControl();

  // Turn on the lights.
  lights();

  // Rotate the coordinate system.
  rotateY(frameCount * 0.01);

  // Style the p5.Geometry object.
  //fill(255,0,0);
  noFill();
  stroke(0,0,255);
  
  textFont(font);
  textAlign(CENTER);

  // Display the p5.Geometry object.
  //model(myGeometry);

  // Style the vertices.
  fill(255, 0, 0);
  noStroke();
  

  // Iterate over the vertices array.
  for (let v of myGeometry.vertices) {
    // Draw a sphere to mark the vertex.
    push();
    //rotateZ(n);
    translate(0,0,v.z);
    text("z",v.x, v.y);
    //sphere(2.5);
    pop();
  }
  
  //n+=.02;
}